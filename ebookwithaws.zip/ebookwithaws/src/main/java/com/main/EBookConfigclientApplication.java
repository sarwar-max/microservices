package com.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.main.model.Book;
import com.main.repository.BookRepository;

@SpringBootApplication
public class EBookConfigclientApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(EBookConfigclientApplication.class, args);
	}

	@Autowired
	@Qualifier("bookRepository")
	BookRepository bookRepository;
	
	@Override
	public void run(String... args) throws Exception {
		bookRepository.save(new Book(0, "Java", "Oracle", "978-1-28", 180, "1995"));
		bookRepository.save(new Book(0, "UX Design", "Thomos", "978-1-28", 130, "1962"));
		bookRepository.save(new Book(0, ".Net", "Martin", "978-1-28", 260, "1956"));
		
		System.out.println(bookRepository.findAll());
		
	}

}
