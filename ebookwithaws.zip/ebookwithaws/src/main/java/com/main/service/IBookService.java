package com.main.service;

import java.util.List;

import com.main.model.Book;

public interface IBookService {
	
	Book saveBook(Book book);
	List<Book> saveBooks(List<Book> books);
	List<Book> findAllBooks();
	Book findBookById(int id);
	List<Book> findAllBooksByTitle(String title);
	List<Book> findAllBooksByPublisher(String publisher);
	List<Book> findAllBooksByYear(String year);
	Book update(Book book);
	void delete(int id);
}
